# Amar Khata — GitHub APK

Fixed Amar Khata (`amar-khata-fixed.html`) wrapped in an Android WebView app.

## Phone steps (GitHub)
1. GitHub-e notun repo khulun (e.g. `amar-khata`), ei zip-er **vitorer sob file** upload korun (zip file-ta na, vitorer file gulu).
2. Repo-r **Actions** tab-e jan — `Build APK` workflow cholbe. Ses hole **Artifacts** theke `amar-khata-apk` download korun.
3. Zip khule `app-debug.apk` phone-e install korun.

## Note
- Eita debug APK — nijer phone-e cholbe. Por-e onno signature-er APK install korle ager app uninstall korte hobe, tai age PDF backup niye rakhben.
- PDF download WebView-teo cholbe (blob download handle kora ache) — PDF Downloads folder-e save hobe.
- Data phone-er app-er vitore save thake (localStorage). Phone change korle PDF backup diye notun phone-e hisab dekhte parben, kintu data auto transfer hobe na.
